import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Menu, X, Search } from "lucide-react";
import { useState } from "react";
import { useCategories } from "@/hooks/use-content";

export function Header() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { data: categories } = useCategories();

  return (
    <header className="border-b border-border bg-background sticky top-0 z-50">
      {/* Top Bar - Date & Edition */}
      <div className="hidden md:flex justify-between items-center py-2 px-6 border-b border-border/50 text-xs font-mono uppercase tracking-widest text-muted-foreground bg-secondary/30">
        <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
        <span>Vol. 1 · Issue 24</span>
        <span>Jakarta / London / Istanbul</span>
      </div>

      <div className="container mx-auto px-4 md:px-8">
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex flex-col items-start group">
            <h1 className="text-2xl md:text-3xl font-black font-serif tracking-tight group-hover:text-primary transition-colors">
              ARVAAS JOURNAL
            </h1>
            <span className="text-[10px] md:text-xs font-mono uppercase tracking-widest text-primary font-bold">
              Critical Islamic Political Economy
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link href="/" className={cn("text-sm font-medium hover:text-primary transition-colors uppercase tracking-wide", location === "/" && "text-primary font-bold")}>
              Home
            </Link>
            {categories?.map((cat) => (
              <Link 
                key={cat.id} 
                href={`/category/${cat.slug}`}
                className={cn("text-sm font-medium hover:text-primary transition-colors uppercase tracking-wide", location === `/category/${cat.slug}` && "text-primary font-bold")}
              >
                {cat.name}
              </Link>
            ))}
            <Link href="/about" className="text-sm font-medium hover:text-primary transition-colors uppercase tracking-wide">
              About
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-secondary rounded-full transition-colors">
              <Search className="w-5 h-5" />
            </button>
            <button 
              className="lg:hidden p-2 hover:bg-secondary rounded-full transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <button className="hidden md:block px-4 py-2 bg-primary text-primary-foreground text-sm font-bold uppercase tracking-widest hover:bg-primary/90 transition-colors">
              Subscribe
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-border bg-background absolute w-full left-0 animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col p-6 gap-4">
            <Link href="/" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-serif font-bold border-b border-border pb-2">
              Home
            </Link>
            {categories?.map((cat) => (
              <Link 
                key={cat.id} 
                href={`/category/${cat.slug}`}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-lg font-serif font-bold border-b border-border pb-2"
              >
                {cat.name}
              </Link>
            ))}
            <Link href="/about" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-serif font-bold border-b border-border pb-2">
              About
            </Link>
            <button className="mt-4 w-full py-3 bg-primary text-primary-foreground font-bold uppercase tracking-widest">
              Subscribe
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
