import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-secondary/50 border-t border-border mt-24">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          
          <div className="md:col-span-1 space-y-6">
            <div className="space-y-1">
              <h2 className="text-2xl font-black font-serif tracking-tight">ARVAAS JOURNAL</h2>
              <p className="text-xs uppercase tracking-widest text-primary font-bold">Est. 2024</p>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Jurnalisme kritis ekonomi Islam & tatanan dunia. Analisis mendalam dari perspektif Islamic political economy.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-serif font-bold text-lg">Rubrik</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/category/moneter-kekuasaan" className="hover:text-primary hover:underline">Moneter & Kekuasaan</Link></li>
              <li><Link href="/category/ziswaf-negara" className="hover:text-primary hover:underline">ZISWAF & Negara</Link></li>
              <li><Link href="/category/kapitalisme-kritik" className="hover:text-primary hover:underline">Kapitalisme & Kritik Islam</Link></li>
              <li><Link href="/category/dunia-islam" className="hover:text-primary hover:underline">Dunia Islam Global</Link></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-serif font-bold text-lg">Company</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/about" className="hover:text-primary hover:underline">About Us</Link></li>
              <li><Link href="#" className="hover:text-primary hover:underline">Editorial Policy</Link></li>
              <li><Link href="#" className="hover:text-primary hover:underline">Contact</Link></li>
              <li><Link href="#" className="hover:text-primary hover:underline">Subscribe</Link></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-serif font-bold text-lg">Newsletter</h3>
            <p className="text-sm text-muted-foreground">Weekly analysis delivered to your inbox.</p>
            <form className="flex gap-2" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Email address" 
                className="flex-1 px-3 py-2 border border-border bg-background focus:outline-none focus:border-primary text-sm"
              />
              <button className="px-4 py-2 bg-foreground text-background font-bold text-sm uppercase tracking-wide hover:bg-primary transition-colors">
                Join
              </button>
            </form>
          </div>

        </div>

        <div className="mt-16 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center text-xs text-muted-foreground font-mono uppercase tracking-wider">
          <p>© 2024 Arvaas Journal. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary">Twitter</a>
            <a href="#" className="hover:text-primary">LinkedIn</a>
            <a href="#" className="hover:text-primary">Instagram</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
