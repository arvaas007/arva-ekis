import { Link } from "wouter";
import { type ArticleWithRelations } from "@shared/schema";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface ArticleCardProps {
  article: ArticleWithRelations;
  variant?: "featured" | "standard" | "compact" | "minimal";
  className?: string;
}

export function ArticleCard({ article, variant = "standard", className }: ArticleCardProps) {
  const publishedDate = article.publishedAt ? format(new Date(article.publishedAt), "MMMM d, yyyy") : "";

  // FEATURED VARIANT (Large Hero)
  if (variant === "featured") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className={cn("group cursor-pointer grid grid-cols-1 md:grid-cols-2 gap-8 items-center mb-16", className)}>
          <div className="relative aspect-[4/3] md:aspect-[16/9] w-full overflow-hidden shadow-2xl">
            {article.coverImageUrl && (
              <img 
                src={article.coverImageUrl} 
                alt={article.title}
                className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-700 ease-out"
              />
            )}
            <div className="absolute inset-0 ring-1 ring-inset ring-black/10"></div>
          </div>
          
          <div className="space-y-4 md:pl-4">
            <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-widest text-primary font-bold">
              {article.category?.name && <span>{article.category.name}</span>}
              <span className="w-1 h-1 bg-primary rounded-full"></span>
              <span>{publishedDate}</span>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-serif font-bold leading-tight group-hover:text-primary transition-colors duration-300">
              {article.title}
            </h2>
            
            <p className="text-lg text-muted-foreground leading-relaxed line-clamp-3 font-serif">
              {article.summary}
            </p>
            
            <div className="pt-4 flex items-center gap-3">
              {article.author?.avatarUrl && (
                <img src={article.author.avatarUrl} alt={article.author.name} className="w-8 h-8 rounded-full border border-border" />
              )}
              <span className="text-sm font-medium uppercase tracking-wide">{article.author?.name}</span>
            </div>
          </div>
        </article>
      </Link>
    );
  }

  // STANDARD VARIANT (Card)
  if (variant === "standard") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className={cn("group cursor-pointer flex flex-col h-full", className)}>
          <div className="relative aspect-[3/2] w-full overflow-hidden mb-5 bg-muted">
            {article.coverImageUrl && (
              <img 
                src={article.coverImageUrl} 
                alt={article.title}
                className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-500"
              />
            )}
            <div className="absolute inset-0 ring-1 ring-inset ring-black/5"></div>
          </div>
          
          <div className="flex flex-col flex-grow space-y-3">
            <div className="text-[10px] font-mono uppercase tracking-widest text-primary font-bold">
              {article.category?.name}
            </div>
            
            <h3 className="text-xl md:text-2xl font-serif font-bold leading-snug group-hover:text-primary transition-colors">
              {article.title}
            </h3>
            
            <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-4 flex-grow">
              {article.summary}
            </p>
            
            <div className="text-xs text-muted-foreground font-mono border-t border-border pt-3 mt-auto flex justify-between">
              <span>{article.author?.name}</span>
              <span>{article.readTime} min read</span>
            </div>
          </div>
        </article>
      </Link>
    );
  }

  // COMPACT VARIANT (Sidebar / List)
  if (variant === "compact") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className={cn("group cursor-pointer py-4 border-b border-border/50 hover:bg-secondary/20 transition-colors", className)}>
          <div className="space-y-2">
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground flex justify-between">
               <span className="text-primary">{article.category?.name}</span>
               <span>{publishedDate}</span>
            </div>
            <h3 className="text-lg font-serif font-bold leading-tight group-hover:text-primary transition-colors">
              {article.title}
            </h3>
            <p className="text-xs text-muted-foreground line-clamp-2">
              {article.summary}
            </p>
          </div>
        </article>
      </Link>
    );
  }

  // MINIMAL VARIANT (Text only)
  return (
    <Link href={`/article/${article.slug}`}>
      <article className={cn("group cursor-pointer py-2", className)}>
        <h4 className="text-base font-medium font-serif group-hover:text-primary group-hover:underline decoration-1 underline-offset-4 transition-all">
          {article.title}
        </h4>
        <div className="text-[10px] text-muted-foreground mt-1 font-mono uppercase">
          {article.author?.name}
        </div>
      </article>
    </Link>
  );
}
