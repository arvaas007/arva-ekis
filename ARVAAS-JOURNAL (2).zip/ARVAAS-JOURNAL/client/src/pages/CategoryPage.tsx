import { useArticles, useCategories } from "@/hooks/use-content";
import { ArticleCard } from "@/components/ArticleCard";
import { Loader2 } from "lucide-react";
import { useRoute } from "wouter";
import { motion } from "framer-motion";

export default function CategoryPage() {
  const [, params] = useRoute("/category/:slug");
  const slug = params?.slug || "";
  
  const { data: articles, isLoading: loadingArticles } = useArticles({ category: slug });
  const { data: categories } = useCategories();
  
  const currentCategory = categories?.find(c => c.slug === slug);

  if (loadingArticles) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="container mx-auto px-4 md:px-6 py-12"
    >
      <header className="mb-16 border-b-4 border-black pb-8">
        <span className="text-xs font-mono uppercase tracking-widest text-primary font-bold block mb-2">Category</span>
        <h1 className="text-5xl md:text-7xl font-serif font-black tracking-tight mb-6">
          {currentCategory?.name || "Archive"}
        </h1>
        {currentCategory?.description && (
          <p className="text-xl text-muted-foreground font-serif max-w-2xl leading-relaxed">
            {currentCategory.description}
          </p>
        )}
      </header>

      {articles && articles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-16">
          {articles.map((article, i) => (
            <ArticleCard 
              key={article.id} 
              article={article} 
              variant="standard" 
              className={i === 0 ? "md:col-span-2 md:text-xl" : ""}
            />
          ))}
        </div>
      ) : (
        <div className="py-24 text-center border border-dashed border-border">
          <h3 className="text-2xl font-serif text-muted-foreground">No articles found in this section yet.</h3>
        </div>
      )}
    </motion.div>
  );
}
