import { useArticles, useCategories } from "@/hooks/use-content";
import { ArticleCard } from "@/components/ArticleCard";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: featuredArticles, isLoading: loadingFeatured } = useArticles({ limit: 1 });
  const { data: latestArticles, isLoading: loadingLatest } = useArticles({ limit: 6 });
  const { data: categories } = useCategories();

  if (loadingFeatured || loadingLatest) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Ensure we don't duplicate the featured article in the latest list if API doesn't handle exclusion
  const leadStory = featuredArticles?.[0];
  const secondaryStories = latestArticles?.filter(a => a.id !== leadStory?.id) || [];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="container mx-auto px-4 md:px-6 py-12"
    >
      
      {/* LEAD STORY */}
      {leadStory && (
        <section className="mb-24">
          <ArticleCard article={leadStory} variant="featured" />
        </section>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 border-t border-black pt-12">
        
        {/* MAIN FEED */}
        <div className="lg:col-span-8">
          <div className="flex items-baseline justify-between mb-8 border-b-4 border-black pb-2">
            <h2 className="text-2xl font-black font-sans uppercase tracking-tighter">Latest Analysis</h2>
            <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Updated Daily</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-12">
            {secondaryStories.slice(0, 4).map((article) => (
              <ArticleCard key={article.id} article={article} variant="standard" />
            ))}
          </div>
        </div>

        {/* SIDEBAR */}
        <aside className="lg:col-span-4 space-y-12">
          
          {/* Policy Briefs Section */}
          <div className="bg-secondary/30 p-6 border border-border">
            <h3 className="text-lg font-bold font-serif mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-accent rounded-full"></span>
              Policy Briefs
            </h3>
            <div className="space-y-4 divide-y divide-border/50">
              {secondaryStories.slice(4, 7).map((article) => (
                <ArticleCard key={article.id} article={article} variant="compact" className="border-0 pt-4 first:pt-0" />
              ))}
            </div>
            <button className="w-full mt-6 py-2 border border-foreground text-xs font-bold uppercase tracking-widest hover:bg-foreground hover:text-background transition-colors">
              View Archive
            </button>
          </div>

          {/* Categories Quick Links */}
          <div>
            <h3 className="text-sm font-bold font-sans uppercase tracking-widest border-b border-black pb-2 mb-4">
              Topics
            </h3>
            <ul className="space-y-3">
              {categories?.map((cat) => (
                <li key={cat.id} className="flex justify-between items-center group cursor-pointer">
                  <a href={`/category/${cat.slug}`} className="font-serif text-lg group-hover:text-primary transition-colors">
                    {cat.name}
                  </a>
                  <span className="text-xs font-mono text-muted-foreground group-hover:text-primary">↗</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter Box */}
          <div className="border border-primary bg-primary/5 p-6 text-center">
            <h4 className="font-serif font-bold text-xl mb-2 text-primary">The Weekly Brief</h4>
            <p className="text-sm text-muted-foreground mb-4">
              Essential analysis on Islamic economy delivered every Friday.
            </p>
            <input 
              className="w-full px-3 py-2 text-sm border border-primary/20 bg-background mb-2 text-center"
              placeholder="Your email address"
            />
            <button className="w-full py-2 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest hover:bg-primary/90">
              Subscribe Free
            </button>
          </div>

        </aside>
      </div>
    </motion.div>
  );
}
