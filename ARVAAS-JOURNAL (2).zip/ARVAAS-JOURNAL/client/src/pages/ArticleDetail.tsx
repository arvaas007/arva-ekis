import { useArticle } from "@/hooks/use-content";
import { useRoute } from "wouter";
import { format } from "date-fns";
import { Loader2, Calendar, Clock, Share2, Printer } from "lucide-react";
import { motion } from "framer-motion";

export default function ArticleDetail() {
  const [, params] = useRoute("/article/:slug");
  const { data: article, isLoading, error } = useArticle(params?.slug || "");

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center p-6">
        <h1 className="text-4xl font-serif font-bold mb-4">404</h1>
        <p className="text-muted-foreground mb-8">Article not found.</p>
        <a href="/" className="px-6 py-3 bg-primary text-primary-foreground uppercase tracking-widest text-sm font-bold">Return Home</a>
      </div>
    );
  }

  return (
    <motion.article 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      transition={{ duration: 0.5 }}
      className="min-h-screen pb-24"
    >
      {/* Header Section */}
      <header className="container mx-auto px-4 md:px-0 max-w-4xl pt-16 pb-12 text-center">
        <div className="flex justify-center items-center gap-2 mb-6">
          <span className="bg-secondary px-3 py-1 text-xs font-mono uppercase tracking-widest font-bold text-primary">
            {article.category?.name}
          </span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-serif font-black leading-tight mb-8 text-balance">
          {article.title}
        </h1>
        
        <p className="text-xl md:text-2xl text-muted-foreground font-serif italic mb-8 max-w-2xl mx-auto leading-relaxed">
          {article.summary}
        </p>

        <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-sm border-y border-border py-6">
          <div className="flex items-center gap-3">
            {article.author?.avatarUrl && (
              <img src={article.author.avatarUrl} alt={article.author.name} className="w-10 h-10 rounded-full border border-border" />
            )}
            <div className="text-left">
              <div className="font-bold font-sans uppercase tracking-wide">{article.author?.name}</div>
              <div className="text-xs text-muted-foreground font-mono">{article.author?.bio || "Contributor"}</div>
            </div>
          </div>
          
          <div className="hidden md:block w-px h-8 bg-border"></div>
          
          <div className="flex gap-6 text-muted-foreground font-mono text-xs uppercase tracking-wider">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {article.publishedAt && format(new Date(article.publishedAt), "MMM d, yyyy")}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              {article.readTime} min read
            </div>
          </div>
        </div>
      </header>

      {/* Featured Image */}
      {article.coverImageUrl && (
        <div className="container mx-auto max-w-5xl mb-16">
          <div className="aspect-[21/9] w-full overflow-hidden shadow-2xl relative group">
            <img 
              src={article.coverImageUrl} 
              alt={article.title} 
              className="object-cover w-full h-full"
            />
             <div className="absolute inset-0 ring-1 ring-inset ring-black/10"></div>
          </div>
          <div className="text-xs text-muted-foreground font-mono text-right mt-2 px-4">
            Image credit: Unsplash / Editorial Use
          </div>
        </div>
      )}

      {/* Content & Sidebar Layout */}
      <div className="container mx-auto px-4 md:px-0 max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* Sticky Sidebar (Share & TOC) */}
        <aside className="hidden lg:block lg:col-span-2 h-full">
          <div className="sticky top-32 flex flex-col items-center gap-4">
            <button className="p-3 rounded-full hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground" title="Share">
              <Share2 className="w-5 h-5" />
            </button>
            <button className="p-3 rounded-full hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground" title="Print">
              <Printer className="w-5 h-5" />
            </button>
            <div className="w-px h-12 bg-border my-2"></div>
            <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground vertical-text" style={{ writingMode: 'vertical-rl' }}>
              Arvaas Journal
            </span>
          </div>
        </aside>

        {/* Main Content */}
        <div className="lg:col-span-8">
          <div 
            className="prose prose-lg prose-headings:font-serif prose-headings:font-bold prose-p:font-serif prose-p:text-lg prose-p:leading-8 max-w-none text-foreground/90 drop-cap"
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Article Footer */}
          <div className="mt-16 pt-8 border-t border-black">
            <h3 className="text-sm font-bold uppercase tracking-widest mb-4">About the Author</h3>
            <div className="bg-secondary/30 p-6 flex gap-6 items-start">
              {article.author?.avatarUrl && (
                <img src={article.author.avatarUrl} alt={article.author.name} className="w-16 h-16 rounded-full grayscale" />
              )}
              <div>
                <h4 className="font-serif font-bold text-lg mb-2">{article.author?.name}</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {article.author?.bio || "An expert contributor to Arvaas Journal focusing on Islamic finance and global political structures."}
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </motion.article>
  );
}
