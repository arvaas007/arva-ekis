import { motion } from "framer-motion";

export default function About() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }} 
      animate={{ opacity: 1, y: 0 }} 
      className="container mx-auto px-4 md:px-0 max-w-3xl py-24"
    >
      <header className="text-center mb-16">
        <h1 className="text-5xl font-serif font-black mb-6">About Arvaas Journal</h1>
        <div className="w-24 h-1 bg-primary mx-auto"></div>
      </header>

      <div className="prose prose-lg prose-headings:font-serif prose-p:font-serif prose-p:text-lg text-foreground/80">
        <p className="lead text-xl md:text-2xl font-serif italic text-foreground mb-8 text-center">
          "Reimagining the global economic order through the lens of critical Islamic political economy."
        </p>

        <h3>Our Mission</h3>
        <p>
          Arvaas Journal is not a news outlet for breaking stories, nor is it a platform for religious preaching. 
          Instead, we position ourselves as a serious analytical journal dedicated to dissecting the mechanisms of global capitalism, 
          monetary systems, and development from a rigorous Islamic perspective.
        </p>

        <h3>What We Cover</h3>
        <ul>
          <li><strong>Monetary & Power:</strong> The nature of fiat money, CBDCs, dedollarization, and the history of currency from the Prophetic era to modernity.</li>
          <li><strong>ZISWAF & The State:</strong> Zakat as a fiscal instrument, Waqf as sovereign wealth, and the role of the state in distribution.</li>
          <li><strong>Capitalism & Critique:</strong> Structural exploitation, financialization, and debt cycles.</li>
          <li><strong>Global Islamic World:</strong> OIC dynamics, BRICS, and the role of the Global South.</li>
        </ul>

        <h3>Our Audience</h3>
        <p>
          We write for academics, students of economics, policy makers, and serious thinkers who are dissatisfied with superficial analyses. 
          Our content is dense, referenced, and designed to challenge prevailing orthodoxies.
        </p>
      </div>

      <div className="mt-16 p-8 bg-secondary/30 border border-border text-center">
        <h4 className="font-bold uppercase tracking-widest mb-4">Contact Editorial Team</h4>
        <p className="text-muted-foreground mb-6">
          For inquiries, submissions, or academic partnerships.
        </p>
        <a href="mailto:editor@arvaasjournal.com" className="inline-block px-8 py-3 bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:bg-primary/90 transition-colors">
          Email Us
        </a>
      </div>
    </motion.div>
  );
}
