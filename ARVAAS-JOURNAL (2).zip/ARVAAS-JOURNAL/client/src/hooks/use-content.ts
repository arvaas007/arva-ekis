import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type ArticleWithRelations, type Category } from "@shared/schema";

export function useArticles(params?: { category?: string; limit?: number }) {
  // Construct query key including params to ensure refetch on change
  const queryKey = [api.articles.list.path, params];
  
  return useQuery({
    queryKey,
    queryFn: async () => {
      // Build query string manually since fetch/api doesn't do it automatically for GET params usually
      const url = new URL(api.articles.list.path, window.location.origin);
      if (params?.category) url.searchParams.append("category", params.category);
      if (params?.limit) url.searchParams.append("limit", params.limit.toString());

      const res = await fetch(url.toString());
      if (!res.ok) throw new Error("Failed to fetch articles");
      
      // Validation with Zod schema from routes
      return api.articles.list.responses[200].parse(await res.json());
    },
  });
}

export function useArticle(slug: string) {
  return useQuery({
    queryKey: [api.articles.get.path, slug],
    queryFn: async () => {
      const url = buildUrl(api.articles.get.path, { slug });
      const res = await fetch(url);
      
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch article");
      
      return api.articles.get.responses[200].parse(await res.json());
    },
    enabled: !!slug,
  });
}

export function useCategories() {
  return useQuery({
    queryKey: [api.categories.list.path],
    queryFn: async () => {
      const res = await fetch(api.categories.list.path);
      if (!res.ok) throw new Error("Failed to fetch categories");
      return api.categories.list.responses[200].parse(await res.json());
    },
  });
}
